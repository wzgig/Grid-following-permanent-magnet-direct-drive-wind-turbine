clear;
clc;

f    = 50;
Fnom    = f;
Np  = 48;
w_g = 2*pi*f;
Sbase = 2e6;
Vbase = 690;
Ibase = Sbase/(sqrt(3)*Vbase);
wbase = w_g;
Zbase = Vbase^2/Sbase;
Lbase = Zbase/w_g;%电感基值
Cbase = 1/(wbase*Zbase);%电容基值
Tbase = Sbase/(w_g/Np);
U_dcref = 1150;
Kp_PLL = 250;
Ki_PLL = 3200;
ugq_ref = 0;
%% ---- 输入参数 ----
P  = -1;        % 有功功率（标幺值）。发电模式为负值（按你的约定）
Q  = 0;         % 无功功率（标幺值）
V  = 0.9998;    % 电压幅值（标幺值）
xi = 0.09;     % 电压相角（弧度）

%% ---- 电网电压的α-β坐标系表示（功率不变框架下v_alpha、v_beta取值相同；缩放系数体现在p,q方程中） ----
v_ab    = V * exp(1i*xi);
v_alpha = real(v_ab);  % 电压α轴分量
v_beta  = imag(v_ab);  % 电压β轴分量

%% ---- 从p-q方程求解i_alpha、i_beta（等功率 => 不含3/2系数） ----
% p = v_alpha*i_alpha + v_beta*i_beta
% q = v_beta*i_alpha  - v_alpha*i_beta

v2 = v_alpha^2 + v_beta^2;   % 等于V²

if v2 < 1e-12
    error('电压幅值过小：无法计算电流参考值。');
end

% 逆映射公式（等功率）：
% [i_alpha; i_beta] = 1/v2 * [ v_alpha  v_beta;
%                              v_beta  -v_alpha] * [P; Q]
i_vec   = 1 / v2 * [ v_alpha,  v_beta;
                     v_beta,  -v_alpha ] * [P; Q];

i_alpha = i_vec(1);
i_beta  = i_vec(2);
i_ab    = i_alpha + 1i*i_beta;

syms PLL_int thetapll
%% ========== 坐标变换（GSC的电压观测） ==========
% PLL
theta_g = thetapll;         % 网侧PLL估计的同步角
% 构造变换矩阵，将d-q轴量转换为定轴坐标系（用于测量或控制）
Tg_alphabeta_dq = [cos(theta_g) sin(theta_g); -sin(theta_g) cos(theta_g)];
vg_dq_real = Vbase * Tg_alphabeta_dq * [v_alpha; v_beta];  % GSC中的实际电压
% 变换后各轴上的电压值提取
v_g_d = vg_dq_real(1);          % 网侧d轴电压
v_g_q = -vg_dq_real(2);         % 网侧q轴电压

%% ========== xi求解 ==========
eqnq = Ki_PLL*(v_g_q/Vbase - ugq_ref) == 0;          % state16
[pllg] = solve(eval([eqnq]),[thetapll]);
thetapll = vpa(pllg(2));
PLL_int = 0;
%% ---- 主程序 ----
run("PMSGRef_and_Para.m");
Tg_dq_alphabeta = [cos(theta_g) -sin(theta_g); sin(theta_g) cos(theta_g)];
ig_dig_alphabeta = (1/Ibase)*Tg_dq_alphabeta*[i_gd;i_gq];

i_galpha = ig_dig_alphabeta(1);
i_gbeta = ig_dig_alphabeta(2);

eqn1 = (Te - T_m - D_m*omega_m) / J == 0;
eqn2 = u_sq - R_s*i_sq - omega_e*Psi_sd == 0;
eqn3 = u_sd - R_s*i_sd + omega_e*Psi_sq == 0;
% eqn2 = (u_sq - R_s*i_sq - omega_e*L_sd*i_sd - omega_e*Psi_f)/L_sq == 0;
% eqn3 = (u_sd - R_s*i_sd + omega_e*L_sq*i_sq)/L_sd == 0;
eqn4 = i_sdref - i_sd == 0;
eqn5 = i_sqref - i_sq == 0;
eqn6 = n_ref - n == 0;
eqn7 = (u_sdref - u_sd)/T_d == 0;
eqn8 = (u_sqref - u_sq)/T_d == 0;
eqn11 = (P_s - P_dc)/(C_dc*U_dc) == 0;
eqn12 = U_dc - U_dcref == 0;
eqn13 = (v_g_d - u_gd - R_g*i_gd + w_g*L_g*i_gq)/L_g == 0;
eqn14 = (v_g_q - u_gq - R_g*i_gq - w_g*L_g*i_gd)/L_g == 0;
eqn15 = i_gdref - i_gd == 0;
eqn16 = i_gqref - i_gq == 0;
eqn17 = i_galpha - i_alpha == 0;
eqn18 = i_gbeta - i_beta == 0;

[omega_m, Psi_sq, Psi_sd, Id_stator_int, Iq_stator_int, Speed_int,...
    u_sd, u_sq, U_dc, Udc_int, i_gd, i_gq, Id_grid_int, Iq_grid_int,...
    v_w, i_gqref]...
                      = vpasolve(eval([eqn1,eqn2,eqn3,eqn4,eqn5,eqn6, ...
                      eqn7,eqn8,eqn11,eqn12,eqn13,eqn14,eqn15,eqn16, ...
                      eqn17,eqn18]),...
                      [omega_m Psi_sq Psi_sd Id_stator_int Iq_stator_int Speed_int ...
                      u_sd u_sq U_dc Udc_int i_gd i_gq Id_grid_int Iq_grid_int ...
                      v_w i_gqref],...
                      [-inf,inf;-inf,inf;-inf,inf;-inf,inf;-inf,inf;-inf,inf;-inf,inf;-inf,inf; ...
                      -inf,inf;-inf,inf;-inf,inf;-inf,inf;-inf,inf;-inf,inf; ...
                      -inf,inf;-inf,inf]);

inistate = [omega_m Psi_sq Psi_sd Id_stator_int Iq_stator_int Speed_int...
    u_sd u_sq PLL_int thetapll U_dc Udc_int i_gd i_gq Id_grid_int Iq_grid_int]'
state_size = size(inistate,1);

v_w = double(v_w);
i_gqref = double(i_gqref);
disp(v_w);disp(i_gqref);

dt = 0.00001;
tspan=dt:dt:10;
options = odeset('RelTol',1e-12,'AbsTol',...
    1e-12*ones(1,state_size));
[t,x] = ode45(@(t,x) PMSG(t,x,v_w, i_gqref),tspan,double(inistate),options);

% run("PMSGRef_and_Para.m");

%%%%%%%%%% states

omega_m = x(:,1);
Psi_sq = x(:,2);
Psi_sd = x(:,3);
Id_stator_int = x(:,4);  % 原x1：定子d轴电流环积分状态
Iq_stator_int = x(:,5);  % 原x2：定子q轴电流环积分状态
Speed_int = x(:,6);      % 原y1：转速环积分状态
u_sd = x(:,7);
u_sq = x(:,8);
PLL_int = x(:,9);        % 原xpll：锁相环积分状态
thetapll = x(:,10);
U_dc = x(:,11);
Udc_int = x(:,12);       % 原z1：直流电压环积分状态
i_gd = x(:,13);
i_gq = x(:,14);
Id_grid_int = x(:,15);   % 原z2：网侧d轴电流环积分状态
Iq_grid_int = x(:,16);   % 原z3：网侧q轴电流环积分状态

disp(thetapll(1));

% plot(tspan, eval(i_sd), 'DisplayName', 'i_sd');
% hold on;
% plot(tspan, eval(i_sq), 'DisplayName', 'i_sq');
% hold on;
% plot(tspan, u_sd, 'DisplayName', 'u_sd');
% hold on;
% plot(tspan, u_sq, 'DisplayName', 'u_sq');
% hold on;
% plot(tspan, eval(Cp), 'DisplayName', 'Cp');
% hold on;
% plot(tspan, eval(T_m), 'DisplayName', 'T_m');
% hold on;
% % plot(tspan, eval(Tem), 'DisplayName', 'Tem');
% % hold on;
% plot(tspan, eval(Te), 'DisplayName', 'Te');
% hold on;
% plot(tspan, eval(omega_e), 'DisplayName', 'omega_e');
% hold on;
% % plot(tspan, eval(Tem_cmd), 'DisplayName', 'Tem_cmd');
% % hold on;
% plot(tspan, omega_m, 'DisplayName', 'omega_m');
% hold on;
figure(1);
plot(tspan, eval(P_m)/Sbase, 'DisplayName', 'P_m');
hold on;
plot(tspan, eval(-P_s)/Sbase, 'DisplayName', 'P_s');
hold on;
% plot(tspan, eval(-P_e)/Sbase, 'DisplayName', 'P_e');
legend('Location', 'best', 'Interpreter', 'tex');
% plot(tspan, eval(Q_s), 'DisplayName', 'Q_s');
% hold on;
% plot(tspan, eval(P_e), 'DisplayName', 'P_e');
% hold on;
% plot(tspan, eval(n), 'DisplayName', 'n');
% hold on;
% plot(tspan, eval(P_g), 'DisplayName', 'P_g');
% hold on;
% plot(tspan, eval(Q_g), 'DisplayName', 'Q_g');
% hold on;
% plot(tspan, eval(P_dc), 'DisplayName', 'P_dc');
% hold on;
% plot(tspan, eval(u_gd), 'DisplayName', 'u_gd');
% hold on;
% plot(tspan, eval(u_gq), 'DisplayName', 'u_gq');
% hold on;
% plot(tspan, i_gd, 'DisplayName', 'i_gd');
% hold on;
% plot(tspan, i_gq, 'DisplayName', 'i_gq');
% hold on;

figure(2);
plot(tspan, eval(P_g/Sbase), 'DisplayName', 'P_g^{pu}');
hold on;
plot(tspan, eval(Q_g/Sbase), 'DisplayName', 'Q_g^{pu}');
hold on;
legend('Location', 'best', 'Interpreter', 'tex');   % Location参数指定图例位置，'best'表示自动选择最佳位置